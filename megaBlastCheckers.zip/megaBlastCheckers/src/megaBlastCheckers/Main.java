
package megaBlastCheckers;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
public class Main {

	public static void main(String[] args) {	
//there are multiple pages involved in the software so we could
//put each GUI in a function to keep the main method more organized
	
		//paint(); //use this to paint the board
		makeBoard(); //fix this function
		playerTwoScreen();
		playerOneScreen();
		
		//playerOneScreen();
		
		
	}
	public static void playerOneScreen() {
		JFrame frame=new JFrame();
		JLabel player1Prompt=new JLabel("Please Enter a name");
		JButton enter=new JButton("Enter");
		JTextField player1Field= new JTextField("Player1");
		player1Field.setBounds(100,100,52,26); //sets where the user will enter their name
		frame.add(player1Field);
		player1Field.setLayout(null);
		player1Prompt.setBounds(75, 200, 200, 100);
		//player1Prompt.setBounds(75, 0, 200, 100); //use this to change the position of the 
			enter.setBounds(30, 150, 120, 60);										//the player prompt
		//enter.setBounds(30,200, 120, 60); //use this to change the position of the enter button 
		enter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame frameOne=new JFrame();
				frameOne.setSize(300,300);
				System.out.println("button click");
				String name=player1Field.getText();
				System.out.println(name);
				frame.dispose();
				 //frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
				
				//close window
				//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
			}
		});
		
		frame.add(player1Prompt);
		frame.add(enter);
		player1Prompt.setVisible(true);
		frame.add(enter);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		enter.setLayout(null);
		frame.setSize(400,400);
		frame.setLayout(null);
		frame.setVisible(true);
		
	}
	public static void playerTwoScreen() {
		JFrame frame=new JFrame();
		JLabel player2Prompt=new JLabel("Please Enter a name");
		JButton enter=new JButton("Enter");
		JTextField player2Field= new JTextField("Player2");
		frame.add(player2Field);
		String name;
		name=player2Field.toString();//name is for retrieving player name
		
		//player2Field.setBounds(180,90,200,152,126); //sets where the user will enter their name
		//frame.add(player2Field);
		player2Field.setBounds(100,100,52,26);
		//player2Field.setBounds(100,100,100,100);
		player2Prompt.setBounds(75, 200, 200, 100); //use this to change the position of the 
													//the player prompt
		enter.setBounds(30,200, 120, 60);
		enter.addActionListener(new ActionListener(){//use this to change the position of the enter button 
		public void actionPerformed(ActionEvent e) { 
			System.out.println("button click");
			String name=player2Field.getText();
			System.out.println(name);
			frame.dispose();
			frame.setVisible(false);  
		}
	});
	
		
		frame.add(player2Prompt);
		frame.add(enter);
		
	
		//enter.action(null, name) .name wouldve been mouse clicks

		
		//enter.addActionListener(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		player2Prompt.setVisible(true);
		frame.add(enter);
		enter.setLayout(null);
		frame.setSize(400,400);
		//frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setVisible(true);
			
	}
	public static void makeBoard() {
		//checkers boards are 8x8
		
		Color temp=null;
		
		Color col1=Color.black;
		Color col2=Color.red;
		
		int[][] boardDimensions=new int[8][8];
		JFrame frame=new JFrame();
		frame.setLayout(new GridLayout(8,8));
		frame.setTitle("Mega Blast Checkers");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800,600);
		//frame.setLayout(new GridLayout(8,8));
		
		
		
		
		//boardDimensions
		for  (int i=0; i<boardDimensions.length; i++) {
			for (int j =0; j< boardDimensions[i].length; j++) {
				System.out.print( boardDimensions[i][j]);
			}
			System.out.println("");
		}
		
		//JPanel pan=new JPanel();
			//JPanel pan=new JPanel();
				for (int i=0; i<8; i++) {
						if (i%2==0) {
							temp=col1;
						}else 
						{
							temp=col2;
							///pan.setBackground(temp);
							
						}
						for (int j=0; j<8; j++) {
							JPanel pan= new JPanel();
							pan.setBackground(temp);
							if(temp.equals(col1)){
								temp=col2;
							}else {
								temp=col1;
							}
							frame.add(pan);
						}
						//frame.add(pan);
					}
				frame.setVisible(true);
				}
				
	
		
		

	
	//code for making the checker board pattern
    public static void paint(Graphics g) {
    	int rows=8;
    	int col=8;
    //	int col1=8;
    	Color col1=Color.black;
    	Color col2=Color.red;
    	//create colors
    	JFrame frame=new JFrame();
    	frame.setLayout(new GridLayout(rows,col));
    	//JPanel panel = new JPanel();
    	//frame.setLayout(new GridLayout(8,8)); 
    	Color temp=null;
    	for (int i =0; i<rows; i++) {
    		if (i%2==0) {
    		temp=col1;
    		} else temp=col2;
    	
    	} for (int j=0; j<col; j++) {
    		JPanel panel =new JPanel();
    		panel.setBackground(temp);
    	}
    	if (temp.equals(col1)) {
    		temp=col1;
    	}else {
    		temp=col2;
    	}
    	for (int j=0; j<8; j++) {
    		
    		JPanel panel=new JPanel();
			panel.setBackground(temp);
    		if (temp.equals(col1)) {
    			temp=col2;
    		}else {
    			temp=col1;
    		}
    		frame.add(panel);
    	}
    	
    	
    	
    	frame.setVisible(true);
    	//g.drawLine(100, 50, 200, 50);
    	
    	//g.setColor(Color.red);
    	
    //	g.fillOval(100, 50, 15, 15);
    	
		
}
}

